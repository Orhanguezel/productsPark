// -------------------------------------------------------------
// FILE: src/integrations/metahub/rtk/endpoints/functions.endpoints.ts
// -------------------------------------------------------------
import { baseApi } from "../baseApi";

type UnknownRecord = Record<string, unknown>;

// ── small helpers
const toPriceString = (x: unknown): string => {
  if (typeof x === "number") return x.toFixed(2);
  if (typeof x === "string") {
    const n = Number(x.replace(",", "."));
    return Number.isFinite(n) ? n.toFixed(2) : "0.00";
  }
  const n = Number(x ?? 0);
  return Number.isFinite(n) ? n.toFixed(2) : "0.00";
};
const toIntKurus = (x: unknown): number => {
  // PayTR çoğunlukla kuruş ister (örn. 50.00 TL → 5000)
  if (typeof x === "number") return Math.round(x * 100);
  if (typeof x === "string") {
    const n = Number(x.replace(",", "."));
    return Math.round((Number.isFinite(n) ? n : 0) * 100);
  }
  const n = Number(x ?? 0);
  return Math.round((Number.isFinite(n) ? n : 0) * 100);
};

const isPlainObject = (v: unknown): v is UnknownRecord =>
  typeof v === "object" && v !== null && !Array.isArray(v);
const isEmptyObject = (v: unknown): boolean =>
  !isPlainObject(v) || Object.keys(v).length === 0;

const normalizeKeyNames = (o: UnknownRecord): UnknownRecord => {
  const out: UnknownRecord = {};
  for (const [k, v] of Object.entries(o)) {
    switch (k) {
      case "orderId": out.order_id = v; break;
      case "successUrl": out.success_url = v; break;
      case "cancelUrl": out.cancel_url = v; break;
      case "returnUrl": out.return_url = v; break;
      default: out[k] = v;
    }
  }
  return out;
};

const normalizeFnBody = (name: string, body?: unknown): UnknownRecord => {
  const raw = isPlainObject(body) ? body : {};
  const b = normalizeKeyNames(raw);

  // ortak basit normalizasyon
  if (b.amount !== undefined) b.amount = toPriceString(b.amount);
  if (typeof b.currency === "string") b.currency = (b.currency as string).toUpperCase();
  if (b.customer && !isPlainObject(b.customer)) delete b.customer;
  if (b.meta && !isPlainObject(b.meta)) delete b.meta;

  // isim bazlı ek: PayTR genelde kuruş bekler
  if (name === "paytr-get-token" || name === "paytr-havale-get-token") {
    // orderData içindeki rakamsal alanları normalize et
    const od = isPlainObject(b.orderData) ? (b.orderData as UnknownRecord) : {};
    if (od.payment_amount !== undefined) od.payment_amount = toIntKurus(od.payment_amount);
    if (od.final_amount !== undefined) od.final_amount = toIntKurus(od.final_amount);
    b.orderData = od;
  }

  return b;
};

export const functionsApi = baseApi.injectEndpoints({
  endpoints: (b) => ({
    invokeFunction: b.mutation<
      // Facade { result } bekliyor → burada da o şekli döndürüyoruz.
      { result: UnknownRecord },
      { name: string; body?: unknown }
    >({
      query: ({ name, body }) => {
        // alt çizgi / büyük harf varyasyonlarına tolerans
        const safeName = name.replace(/_/g, "-").toLowerCase();

        const normalized = normalizeFnBody(safeName, body);
        const hasBody = !isEmptyObject(normalized);

        return {
          url: `/functions/v1/${encodeURIComponent(safeName)}`,
          method: "POST",
          // Fastify'nin "boş JSON" 400'ünü engelle
          body: hasBody ? normalized : undefined,
          headers: hasBody
            ? { "Content-Type": "application/json", "Accept": "application/json" }
            : { "Accept": "application/json" },
        };
      },

      // Başarılı response'u UI'nin beklediği şekle sar
      transformResponse: (res: unknown, _meta, arg): { result: UnknownRecord } => {
        const payload = (res as UnknownRecord) ?? {};
        const name = arg.name.replace(/_/g, "-").toLowerCase();

        // PayTR (kredi kartı + havale) – FE success/token bekliyor
        if (name === "paytr-get-token" || name === "paytr-havale-get-token") {
          const token = payload.token as string | undefined;
          return {
            result: {
              success: Boolean(token),
              token,
              // opsiyonel alanları forward edelim (FE loglamak isterse)
              forward_payload: (payload as UnknownRecord).forward_payload ?? null,
              expires_in: (payload as UnknownRecord).expires_in ?? null,
            },
          };
        }

        // Shopier – FE form_action + form_data bekliyor
        if (name === "shopier-create-payment") {
          const p = payload as UnknownRecord;
          const form_action = (p.form_action as string) ?? "https://example.com/mock-shopier";
          const form_data =
            (p.form_data as UnknownRecord) ??
            (() => {
              try {
                const url = String(p.payment_url ?? "");
                const m = url.match(/[?&]oid=([^&]+)/i);
                return { oid: m?.[1] ?? `SHP_${Date.now()}` };
              } catch {
                return { oid: `SHP_${Date.now()}` };
              }
            })();

          return { result: { success: true, form_action, form_data } };
        }

        // Genel default: payload'ı result içine koy
        return { result: payload };
      },

      invalidatesTags: ["Functions"],
    }),
  }),
  overrideExisting: true,
});

export const { useInvokeFunctionMutation } = functionsApi;
