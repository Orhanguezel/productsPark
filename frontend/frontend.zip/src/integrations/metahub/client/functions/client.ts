// =============================================================
// FILE: src/integrations/metahub/client/functions/client.ts
// =============================================================
import { store } from "@/store";
import { functionsApi } from "@/integrations/metahub/rtk/endpoints/functions.endpoints";
import type { FunctionsFacade } from "@/integrations/metahub/core/public-api";
import { normalizeError } from "@/integrations/metahub/core/errors";

type InvokeArgs = Readonly<{ body?: unknown }>;
type UnknownRecord = Record<string, unknown>;
const isObj = (v: unknown): v is UnknownRecord => typeof v === "object" && v !== null;

// (İsteğe bağlı) ileride lazım olabilir — şu an için body’yi olduğu gibi ileteceğiz
function adaptBodyByFunction(_name: string, body: unknown): unknown {
  return body;
}

export const functions: FunctionsFacade = {
  async invoke<T = unknown>(name: string, args: InvokeArgs = {}) {
    const transformedBody = adaptBodyByFunction(name, args.body);
    try {
      const { result } = await store
        .dispatch(
          functionsApi.endpoints.invokeFunction.initiate({ name, body: transformedBody })
        )
        .unwrap();
      return { data: result as T, error: null };
    } catch (e: unknown) {
      const { message, status } = normalizeError(e);
      return { data: null, error: { message, status } };
    }
  },
};
