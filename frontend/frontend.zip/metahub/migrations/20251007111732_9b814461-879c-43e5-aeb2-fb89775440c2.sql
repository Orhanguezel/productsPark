-- Enable realtime for cart_items table
ALTER PUBLICATION metahub_realtime ADD TABLE public.cart_items;